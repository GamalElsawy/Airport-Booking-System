﻿namespace WindowsFormsApplication2
{
    partial class edit_flight2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_exit = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.txt_num_of_p_add = new ZBobb.AlphaBlendTextBox();
            this.txt_air_add = new ZBobb.AlphaBlendTextBox();
            this.txt_duration_add = new ZBobb.AlphaBlendTextBox();
            this.txt_dest_add = new ZBobb.AlphaBlendTextBox();
            this.txt_id_delete = new ZBobb.AlphaBlendTextBox();
            this.txt_duration_edit = new ZBobb.AlphaBlendTextBox();
            this.txt_num_of_p_edit = new ZBobb.AlphaBlendTextBox();
            this.txt_air_edit = new ZBobb.AlphaBlendTextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txt_id_edit = new ZBobb.AlphaBlendTextBox();
            this.txt_dest_edit = new ZBobb.AlphaBlendTextBox();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_delete = new System.Windows.Forms.Button();
            this.pnl_delete = new System.Windows.Forms.Panel();
            this.pnl_edit = new System.Windows.Forms.Panel();
            this.pnl_add = new System.Windows.Forms.Panel();
            this.panelleft = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_logout = new System.Windows.Forms.Button();
            this.btn_send_alert = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.editflight = new System.Windows.Forms.Button();
            this.pnl_delete.SuspendLayout();
            this.pnl_edit.SuspendLayout();
            this.pnl_add.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_exit
            // 
            this.btn_exit.BackgroundImage = global::WindowsFormsApplication2.Properties.Resources.exit1;
            this.btn_exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Location = new System.Drawing.Point(1257, 1);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(40, 40);
            this.btn_exit.TabIndex = 39;
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label20.Location = new System.Drawing.Point(4, 40);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(133, 25);
            this.label20.TabIndex = 66;
            this.label20.Text = "Destination :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label19.Location = new System.Drawing.Point(24, 189);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 25);
            this.label19.TabIndex = 65;
            this.label19.Text = "Date :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label18.Location = new System.Drawing.Point(453, 40);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(130, 25);
            this.label18.TabIndex = 64;
            this.label18.Text = "Num_Of_P :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label17.Location = new System.Drawing.Point(13, 116);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(106, 25);
            this.label17.TabIndex = 63;
            this.label17.Text = "Duration :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(466, 116);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 25);
            this.label16.TabIndex = 62;
            this.label16.Text = "Airline :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label15.Location = new System.Drawing.Point(27, 176);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 25);
            this.label15.TabIndex = 61;
            this.label15.Text = "Date :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label14.Location = new System.Drawing.Point(503, 176);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(86, 25);
            this.label14.TabIndex = 60;
            this.label14.Text = "Airline :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label13.Location = new System.Drawing.Point(459, 106);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(130, 25);
            this.label13.TabIndex = 59;
            this.label13.Text = "Num_Of_P :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label12.Location = new System.Drawing.Point(3, 106);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 25);
            this.label12.TabIndex = 58;
            this.label12.Text = "Destination :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label11.Location = new System.Drawing.Point(484, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(106, 25);
            this.label11.TabIndex = 57;
            this.label11.Text = "Duration :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label10.Location = new System.Drawing.Point(27, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 25);
            this.label10.TabIndex = 56;
            this.label10.Text = "ID :";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Location = new System.Drawing.Point(143, 184);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(289, 30);
            this.dateTimePicker2.TabIndex = 55;
            // 
            // txt_num_of_p_add
            // 
            this.txt_num_of_p_add.BackAlpha = 0;
            this.txt_num_of_p_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_num_of_p_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_num_of_p_add.ForeColor = System.Drawing.Color.White;
            this.txt_num_of_p_add.Location = new System.Drawing.Point(607, 34);
            this.txt_num_of_p_add.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_num_of_p_add.MaxLength = 30;
            this.txt_num_of_p_add.Name = "txt_num_of_p_add";
            this.txt_num_of_p_add.Size = new System.Drawing.Size(253, 34);
            this.txt_num_of_p_add.TabIndex = 54;
            // 
            // txt_air_add
            // 
            this.txt_air_add.BackAlpha = 0;
            this.txt_air_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_air_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_air_add.ForeColor = System.Drawing.Color.White;
            this.txt_air_add.Location = new System.Drawing.Point(603, 110);
            this.txt_air_add.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_air_add.MaxLength = 30;
            this.txt_air_add.Name = "txt_air_add";
            this.txt_air_add.Size = new System.Drawing.Size(257, 34);
            this.txt_air_add.TabIndex = 53;
            // 
            // txt_duration_add
            // 
            this.txt_duration_add.BackAlpha = 0;
            this.txt_duration_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_duration_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_duration_add.ForeColor = System.Drawing.Color.White;
            this.txt_duration_add.Location = new System.Drawing.Point(166, 110);
            this.txt_duration_add.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_duration_add.MaxLength = 30;
            this.txt_duration_add.Name = "txt_duration_add";
            this.txt_duration_add.Size = new System.Drawing.Size(244, 34);
            this.txt_duration_add.TabIndex = 52;
            // 
            // txt_dest_add
            // 
            this.txt_dest_add.BackAlpha = 0;
            this.txt_dest_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_dest_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dest_add.ForeColor = System.Drawing.Color.White;
            this.txt_dest_add.Location = new System.Drawing.Point(166, 34);
            this.txt_dest_add.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_dest_add.MaxLength = 30;
            this.txt_dest_add.Name = "txt_dest_add";
            this.txt_dest_add.Size = new System.Drawing.Size(244, 34);
            this.txt_dest_add.TabIndex = 51;
            // 
            // txt_id_delete
            // 
            this.txt_id_delete.BackAlpha = 0;
            this.txt_id_delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_id_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_delete.ForeColor = System.Drawing.Color.White;
            this.txt_id_delete.Location = new System.Drawing.Point(627, 29);
            this.txt_id_delete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_id_delete.MaxLength = 30;
            this.txt_id_delete.Name = "txt_id_delete";
            this.txt_id_delete.Size = new System.Drawing.Size(253, 34);
            this.txt_id_delete.TabIndex = 50;
            this.txt_id_delete.TextChanged += new System.EventHandler(this.txt_id_delete_TextChanged);
            // 
            // txt_duration_edit
            // 
            this.txt_duration_edit.BackAlpha = 0;
            this.txt_duration_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_duration_edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_duration_edit.ForeColor = System.Drawing.Color.White;
            this.txt_duration_edit.Location = new System.Drawing.Point(610, 17);
            this.txt_duration_edit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_duration_edit.MaxLength = 30;
            this.txt_duration_edit.Name = "txt_duration_edit";
            this.txt_duration_edit.Size = new System.Drawing.Size(253, 34);
            this.txt_duration_edit.TabIndex = 49;
            // 
            // txt_num_of_p_edit
            // 
            this.txt_num_of_p_edit.BackAlpha = 0;
            this.txt_num_of_p_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_num_of_p_edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_num_of_p_edit.ForeColor = System.Drawing.Color.White;
            this.txt_num_of_p_edit.Location = new System.Drawing.Point(610, 97);
            this.txt_num_of_p_edit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_num_of_p_edit.MaxLength = 30;
            this.txt_num_of_p_edit.Name = "txt_num_of_p_edit";
            this.txt_num_of_p_edit.Size = new System.Drawing.Size(253, 34);
            this.txt_num_of_p_edit.TabIndex = 48;
            // 
            // txt_air_edit
            // 
            this.txt_air_edit.BackAlpha = 0;
            this.txt_air_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_air_edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_air_edit.ForeColor = System.Drawing.Color.White;
            this.txt_air_edit.Location = new System.Drawing.Point(610, 170);
            this.txt_air_edit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_air_edit.MaxLength = 30;
            this.txt_air_edit.Name = "txt_air_edit";
            this.txt_air_edit.Size = new System.Drawing.Size(253, 34);
            this.txt_air_edit.TabIndex = 47;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(125, 174);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(289, 30);
            this.dateTimePicker1.TabIndex = 46;
            // 
            // txt_id_edit
            // 
            this.txt_id_edit.BackAlpha = 0;
            this.txt_id_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_id_edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_edit.ForeColor = System.Drawing.Color.White;
            this.txt_id_edit.Location = new System.Drawing.Point(170, 20);
            this.txt_id_edit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_id_edit.MaxLength = 30;
            this.txt_id_edit.Name = "txt_id_edit";
            this.txt_id_edit.Size = new System.Drawing.Size(247, 34);
            this.txt_id_edit.TabIndex = 45;
            this.txt_id_edit.TextChanged += new System.EventHandler(this.txt_id_edit_TextChanged);
            // 
            // txt_dest_edit
            // 
            this.txt_dest_edit.BackAlpha = 0;
            this.txt_dest_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_dest_edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dest_edit.ForeColor = System.Drawing.Color.White;
            this.txt_dest_edit.Location = new System.Drawing.Point(170, 97);
            this.txt_dest_edit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_dest_edit.MaxLength = 30;
            this.txt_dest_edit.Name = "txt_dest_edit";
            this.txt_dest_edit.Size = new System.Drawing.Size(247, 34);
            this.txt_dest_edit.TabIndex = 44;
            // 
            // btn_edit
            // 
            this.btn_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_edit.FlatAppearance.BorderSize = 0;
            this.btn_edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_edit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(55)))));
            this.btn_edit.Location = new System.Drawing.Point(894, 23);
            this.btn_edit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(164, 60);
            this.btn_edit.TabIndex = 43;
            this.btn_edit.Text = "Edit";
            this.btn_edit.UseVisualStyleBackColor = false;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_add.FlatAppearance.BorderSize = 0;
            this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(55)))));
            this.btn_add.Location = new System.Drawing.Point(887, 34);
            this.btn_add.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(162, 60);
            this.btn_add.TabIndex = 42;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label9.Location = new System.Drawing.Point(525, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 29);
            this.label9.TabIndex = 41;
            this.label9.Text = "ID :";
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(55)))));
            this.btn_delete.Location = new System.Drawing.Point(911, 16);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(164, 60);
            this.btn_delete.TabIndex = 40;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // pnl_delete
            // 
            this.pnl_delete.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_delete.Controls.Add(this.txt_id_delete);
            this.pnl_delete.Controls.Add(this.label9);
            this.pnl_delete.Controls.Add(this.btn_delete);
            this.pnl_delete.Location = new System.Drawing.Point(203, 76);
            this.pnl_delete.Name = "pnl_delete";
            this.pnl_delete.Size = new System.Drawing.Size(1082, 93);
            this.pnl_delete.TabIndex = 67;
            // 
            // pnl_edit
            // 
            this.pnl_edit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_edit.Controls.Add(this.label15);
            this.pnl_edit.Controls.Add(this.label14);
            this.pnl_edit.Controls.Add(this.label13);
            this.pnl_edit.Controls.Add(this.label12);
            this.pnl_edit.Controls.Add(this.label11);
            this.pnl_edit.Controls.Add(this.label10);
            this.pnl_edit.Controls.Add(this.txt_duration_edit);
            this.pnl_edit.Controls.Add(this.txt_num_of_p_edit);
            this.pnl_edit.Controls.Add(this.txt_air_edit);
            this.pnl_edit.Controls.Add(this.dateTimePicker1);
            this.pnl_edit.Controls.Add(this.txt_id_edit);
            this.pnl_edit.Controls.Add(this.txt_dest_edit);
            this.pnl_edit.Controls.Add(this.btn_edit);
            this.pnl_edit.Location = new System.Drawing.Point(219, 175);
            this.pnl_edit.Name = "pnl_edit";
            this.pnl_edit.Size = new System.Drawing.Size(1066, 223);
            this.pnl_edit.TabIndex = 68;
            this.pnl_edit.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // pnl_add
            // 
            this.pnl_add.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_add.Controls.Add(this.label20);
            this.pnl_add.Controls.Add(this.label19);
            this.pnl_add.Controls.Add(this.label18);
            this.pnl_add.Controls.Add(this.label17);
            this.pnl_add.Controls.Add(this.label16);
            this.pnl_add.Controls.Add(this.dateTimePicker2);
            this.pnl_add.Controls.Add(this.txt_num_of_p_add);
            this.pnl_add.Controls.Add(this.txt_air_add);
            this.pnl_add.Controls.Add(this.txt_duration_add);
            this.pnl_add.Controls.Add(this.txt_dest_add);
            this.pnl_add.Controls.Add(this.btn_add);
            this.pnl_add.Location = new System.Drawing.Point(219, 404);
            this.pnl_add.Name = "pnl_add";
            this.pnl_add.Size = new System.Drawing.Size(1066, 230);
            this.pnl_add.TabIndex = 69;
            // 
            // panelleft
            // 
            this.panelleft.BackColor = System.Drawing.Color.Yellow;
            this.panelleft.Location = new System.Drawing.Point(200, 175);
            this.panelleft.Margin = new System.Windows.Forms.Padding(4);
            this.panelleft.Name = "panelleft";
            this.panelleft.Size = new System.Drawing.Size(4, 90);
            this.panelleft.TabIndex = 71;
            this.panelleft.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_logout);
            this.panel1.Controls.Add(this.panelleft);
            this.panel1.Controls.Add(this.btn_send_alert);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.editflight);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 644);
            this.panel1.TabIndex = 70;
            // 
            // btn_logout
            // 
            this.btn_logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.btn_logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.Location = new System.Drawing.Point(0, 594);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(200, 50);
            this.btn_logout.TabIndex = 0;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = false;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_send_alert
            // 
            this.btn_send_alert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.btn_send_alert.FlatAppearance.BorderSize = 0;
            this.btn_send_alert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_send_alert.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_send_alert.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_send_alert.Location = new System.Drawing.Point(0, 355);
            this.btn_send_alert.Margin = new System.Windows.Forms.Padding(4);
            this.btn_send_alert.Name = "btn_send_alert";
            this.btn_send_alert.Size = new System.Drawing.Size(198, 90);
            this.btn_send_alert.TabIndex = 6;
            this.btn_send_alert.Text = "Send Alert";
            this.btn_send_alert.UseVisualStyleBackColor = false;
            this.btn_send_alert.Click += new System.EventHandler(this.btn_send_alert_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Yellow;
            this.panel2.BackgroundImage = global::WindowsFormsApplication2.Properties.Resources.images__1_2;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(198, 176);
            this.panel2.TabIndex = 1;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.button3.Location = new System.Drawing.Point(0, 265);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(198, 90);
            this.button3.TabIndex = 5;
            this.button3.Text = "Edit Airline";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // editflight
            // 
            this.editflight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.editflight.FlatAppearance.BorderSize = 0;
            this.editflight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editflight.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editflight.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.editflight.Location = new System.Drawing.Point(0, 175);
            this.editflight.Margin = new System.Windows.Forms.Padding(4);
            this.editflight.Name = "editflight";
            this.editflight.Size = new System.Drawing.Size(198, 90);
            this.editflight.TabIndex = 4;
            this.editflight.Text = "Edit Flight";
            this.editflight.UseVisualStyleBackColor = false;
            this.editflight.Click += new System.EventHandler(this.editflight_Click);
            // 
            // edit_flight2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(1297, 644);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnl_add);
            this.Controls.Add(this.pnl_edit);
            this.Controls.Add(this.pnl_delete);
            this.Controls.Add(this.btn_exit);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "edit_flight2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "edit_flight2";
            this.Load += new System.EventHandler(this.edit_flight2_Load);
            this.pnl_delete.ResumeLayout(false);
            this.pnl_delete.PerformLayout();
            this.pnl_edit.ResumeLayout(false);
            this.pnl_edit.PerformLayout();
            this.pnl_add.ResumeLayout(false);
            this.pnl_add.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private ZBobb.AlphaBlendTextBox txt_num_of_p_add;
        private ZBobb.AlphaBlendTextBox txt_air_add;
        private ZBobb.AlphaBlendTextBox txt_duration_add;
        private ZBobb.AlphaBlendTextBox txt_dest_add;
        private ZBobb.AlphaBlendTextBox txt_id_delete;
        private ZBobb.AlphaBlendTextBox txt_duration_edit;
        private ZBobb.AlphaBlendTextBox txt_num_of_p_edit;
        private ZBobb.AlphaBlendTextBox txt_air_edit;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private ZBobb.AlphaBlendTextBox txt_id_edit;
        private ZBobb.AlphaBlendTextBox txt_dest_edit;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Panel pnl_delete;
        private System.Windows.Forms.Panel pnl_edit;
        private System.Windows.Forms.Panel pnl_add;
        private System.Windows.Forms.Panel panelleft;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_send_alert;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button editflight;
        private System.Windows.Forms.Button btn_logout;
    }
}