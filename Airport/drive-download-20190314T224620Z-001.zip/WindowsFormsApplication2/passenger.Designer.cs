﻿namespace WindowsFormsApplication1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_logout = new System.Windows.Forms.Button();
            this.btn_alerts = new System.Windows.Forms.Button();
            this.btn_resch = new System.Windows.Forms.Button();
            this.btn_search_air = new System.Windows.Forms.Button();
            this.btn_search_f = new System.Windows.Forms.Button();
            this.pnl_logo = new System.Windows.Forms.Panel();
            this.pnl_menu_btns = new System.Windows.Forms.Panel();
            this.btn_f_search_dest = new System.Windows.Forms.Button();
            this.btn_f_search_num = new System.Windows.Forms.Button();
            this.btn_all_f_data = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pnl_yellow = new System.Windows.Forms.Panel();
            this.pnl_search_f = new System.Windows.Forms.Panel();
            this.lbl_airline = new System.Windows.Forms.Label();
            this.pnl_search_id = new System.Windows.Forms.Panel();
            this.btn_search_id = new System.Windows.Forms.Button();
            this.txt_f_search_id = new System.Windows.Forms.TextBox();
            this.lbl_num_of_p = new System.Windows.Forms.Label();
            this.pnl_search_dest = new System.Windows.Forms.Panel();
            this.btn_search_dest = new System.Windows.Forms.Button();
            this.txt_f_search_dest = new System.Windows.Forms.TextBox();
            this.lbl_duration = new System.Windows.Forms.Label();
            this.pnl_f_data = new System.Windows.Forms.Panel();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_dest = new System.Windows.Forms.Label();
            this.lbl_flight_num = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.pnl_search_air = new System.Windows.Forms.Panel();
            this.pnl_a_data = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_a_search_name = new System.Windows.Forms.Button();
            this.txt_a_search = new System.Windows.Forms.TextBox();
            this.btn_a_search = new System.Windows.Forms.Button();
            this.btn_a_all_data = new System.Windows.Forms.Button();
            this.pnl_resch_data = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.pnl_resch = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btn_exit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.pnl_menu_btns.SuspendLayout();
            this.pnl_search_f.SuspendLayout();
            this.pnl_search_id.SuspendLayout();
            this.pnl_search_dest.SuspendLayout();
            this.pnl_search_air.SuspendLayout();
            this.pnl_resch.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btn_logout);
            this.panel1.Controls.Add(this.btn_alerts);
            this.panel1.Controls.Add(this.btn_resch);
            this.panel1.Controls.Add(this.btn_search_air);
            this.panel1.Controls.Add(this.btn_search_f);
            this.panel1.Controls.Add(this.pnl_logo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 738);
            this.panel1.TabIndex = 0;
            // 
            // btn_logout
            // 
            this.btn_logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(55)))));
            this.btn_logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_logout.Location = new System.Drawing.Point(-1, 692);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(200, 41);
            this.btn_logout.TabIndex = 8;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = false;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_alerts
            // 
            this.btn_alerts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.btn_alerts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_alerts.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_alerts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(142)))), ((int)(((byte)(194)))));
            this.btn_alerts.Location = new System.Drawing.Point(0, 447);
            this.btn_alerts.Name = "btn_alerts";
            this.btn_alerts.Size = new System.Drawing.Size(198, 90);
            this.btn_alerts.TabIndex = 4;
            this.btn_alerts.Text = "Alerts";
            this.btn_alerts.UseVisualStyleBackColor = false;
            this.btn_alerts.Click += new System.EventHandler(this.btn_alerts_Click);
            // 
            // btn_resch
            // 
            this.btn_resch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.btn_resch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_resch.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_resch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(142)))), ((int)(((byte)(194)))));
            this.btn_resch.Location = new System.Drawing.Point(0, 357);
            this.btn_resch.Name = "btn_resch";
            this.btn_resch.Size = new System.Drawing.Size(198, 90);
            this.btn_resch.TabIndex = 3;
            this.btn_resch.Text = "Re- Schedule";
            this.btn_resch.UseVisualStyleBackColor = false;
            this.btn_resch.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // btn_search_air
            // 
            this.btn_search_air.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.btn_search_air.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search_air.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search_air.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(142)))), ((int)(((byte)(194)))));
            this.btn_search_air.Location = new System.Drawing.Point(0, 267);
            this.btn_search_air.Name = "btn_search_air";
            this.btn_search_air.Size = new System.Drawing.Size(198, 90);
            this.btn_search_air.TabIndex = 2;
            this.btn_search_air.Text = "Search AirLine";
            this.btn_search_air.UseVisualStyleBackColor = false;
            this.btn_search_air.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // btn_search_f
            // 
            this.btn_search_f.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search_f.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search_f.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(142)))), ((int)(((byte)(194)))));
            this.btn_search_f.Location = new System.Drawing.Point(1, 177);
            this.btn_search_f.Name = "btn_search_f";
            this.btn_search_f.Size = new System.Drawing.Size(198, 90);
            this.btn_search_f.TabIndex = 1;
            this.btn_search_f.Text = "Search Flight";
            this.btn_search_f.UseVisualStyleBackColor = true;
            this.btn_search_f.Click += new System.EventHandler(this.button1_Click);
            // 
            // pnl_logo
            // 
            this.pnl_logo.BackColor = System.Drawing.Color.Yellow;
            this.pnl_logo.BackgroundImage = global::WindowsFormsApplication2.Properties.Resources.images__1_6;
            this.pnl_logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_logo.Location = new System.Drawing.Point(0, 0);
            this.pnl_logo.Name = "pnl_logo";
            this.pnl_logo.Size = new System.Drawing.Size(198, 176);
            this.pnl_logo.TabIndex = 0;
            // 
            // pnl_menu_btns
            // 
            this.pnl_menu_btns.Controls.Add(this.btn_f_search_dest);
            this.pnl_menu_btns.Controls.Add(this.btn_f_search_num);
            this.pnl_menu_btns.Controls.Add(this.btn_all_f_data);
            this.pnl_menu_btns.Location = new System.Drawing.Point(7, 7);
            this.pnl_menu_btns.Name = "pnl_menu_btns";
            this.pnl_menu_btns.Size = new System.Drawing.Size(1114, 84);
            this.pnl_menu_btns.TabIndex = 1;
            this.pnl_menu_btns.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSF_Paint);
            // 
            // btn_f_search_dest
            // 
            this.btn_f_search_dest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_f_search_dest.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_f_search_dest.Location = new System.Drawing.Point(740, 23);
            this.btn_f_search_dest.Name = "btn_f_search_dest";
            this.btn_f_search_dest.Size = new System.Drawing.Size(370, 60);
            this.btn_f_search_dest.TabIndex = 2;
            this.btn_f_search_dest.Text = "Search By Distination";
            this.btn_f_search_dest.UseVisualStyleBackColor = true;
            this.btn_f_search_dest.Click += new System.EventHandler(this.button6_Click);
            // 
            // btn_f_search_num
            // 
            this.btn_f_search_num.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_f_search_num.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_f_search_num.Location = new System.Drawing.Point(370, 23);
            this.btn_f_search_num.Name = "btn_f_search_num";
            this.btn_f_search_num.Size = new System.Drawing.Size(370, 60);
            this.btn_f_search_num.TabIndex = 1;
            this.btn_f_search_num.Text = "Search By Number";
            this.btn_f_search_num.UseVisualStyleBackColor = true;
            this.btn_f_search_num.Click += new System.EventHandler(this.searchbyname_Click);
            // 
            // btn_all_f_data
            // 
            this.btn_all_f_data.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.btn_all_f_data.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_all_f_data.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_all_f_data.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_all_f_data.Location = new System.Drawing.Point(0, 23);
            this.btn_all_f_data.Name = "btn_all_f_data";
            this.btn_all_f_data.Size = new System.Drawing.Size(370, 60);
            this.btn_all_f_data.TabIndex = 0;
            this.btn_all_f_data.Text = "All flight data";
            this.btn_all_f_data.UseVisualStyleBackColor = false;
            this.btn_all_f_data.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(163, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(221, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "All Avialable Flights";
            // 
            // pnl_yellow
            // 
            this.pnl_yellow.BackColor = System.Drawing.Color.Yellow;
            this.pnl_yellow.Location = new System.Drawing.Point(200, 177);
            this.pnl_yellow.Name = "pnl_yellow";
            this.pnl_yellow.Size = new System.Drawing.Size(4, 90);
            this.pnl_yellow.TabIndex = 3;
            // 
            // pnl_search_f
            // 
            this.pnl_search_f.Controls.Add(this.lbl_airline);
            this.pnl_search_f.Controls.Add(this.pnl_search_id);
            this.pnl_search_f.Controls.Add(this.lbl_num_of_p);
            this.pnl_search_f.Controls.Add(this.pnl_search_dest);
            this.pnl_search_f.Controls.Add(this.pnl_menu_btns);
            this.pnl_search_f.Controls.Add(this.lbl_duration);
            this.pnl_search_f.Controls.Add(this.pnl_f_data);
            this.pnl_search_f.Controls.Add(this.lbl_date);
            this.pnl_search_f.Controls.Add(this.lbl_dest);
            this.pnl_search_f.Controls.Add(this.lbl_flight_num);
            this.pnl_search_f.Location = new System.Drawing.Point(463, 150);
            this.pnl_search_f.Name = "pnl_search_f";
            this.pnl_search_f.Size = new System.Drawing.Size(1124, 646);
            this.pnl_search_f.TabIndex = 4;
            this.pnl_search_f.Visible = false;
            // 
            // lbl_airline
            // 
            this.lbl_airline.AutoSize = true;
            this.lbl_airline.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_airline.Location = new System.Drawing.Point(828, 198);
            this.lbl_airline.Name = "lbl_airline";
            this.lbl_airline.Size = new System.Drawing.Size(66, 25);
            this.lbl_airline.TabIndex = 5;
            this.lbl_airline.Text = "Airline";
            // 
            // pnl_search_id
            // 
            this.pnl_search_id.Controls.Add(this.btn_search_id);
            this.pnl_search_id.Controls.Add(this.txt_f_search_id);
            this.pnl_search_id.Location = new System.Drawing.Point(646, 97);
            this.pnl_search_id.Name = "pnl_search_id";
            this.pnl_search_id.Size = new System.Drawing.Size(399, 70);
            this.pnl_search_id.TabIndex = 9;
            this.pnl_search_id.Visible = false;
            // 
            // btn_search_id
            // 
            this.btn_search_id.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search_id.Location = new System.Drawing.Point(264, 15);
            this.btn_search_id.Name = "btn_search_id";
            this.btn_search_id.Size = new System.Drawing.Size(132, 34);
            this.btn_search_id.TabIndex = 7;
            this.btn_search_id.Text = "Search";
            this.btn_search_id.UseVisualStyleBackColor = true;
            this.btn_search_id.Click += new System.EventHandler(this.btn_search_id_Click);
            // 
            // txt_f_search_id
            // 
            this.txt_f_search_id.Location = new System.Drawing.Point(43, 25);
            this.txt_f_search_id.Name = "txt_f_search_id";
            this.txt_f_search_id.Size = new System.Drawing.Size(184, 22);
            this.txt_f_search_id.TabIndex = 6;
            this.txt_f_search_id.TextChanged += new System.EventHandler(this.txt_f_search_id_TextChanged);
            // 
            // lbl_num_of_p
            // 
            this.lbl_num_of_p.AutoSize = true;
            this.lbl_num_of_p.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_num_of_p.Location = new System.Drawing.Point(607, 198);
            this.lbl_num_of_p.Name = "lbl_num_of_p";
            this.lbl_num_of_p.Size = new System.Drawing.Size(201, 25);
            this.lbl_num_of_p.TabIndex = 4;
            this.lbl_num_of_p.Text = "Number of Passenger";
            // 
            // pnl_search_dest
            // 
            this.pnl_search_dest.Controls.Add(this.btn_search_dest);
            this.pnl_search_dest.Controls.Add(this.txt_f_search_dest);
            this.pnl_search_dest.Location = new System.Drawing.Point(103, 97);
            this.pnl_search_dest.Name = "pnl_search_dest";
            this.pnl_search_dest.Size = new System.Drawing.Size(399, 70);
            this.pnl_search_dest.TabIndex = 8;
            this.pnl_search_dest.Visible = false;
            // 
            // btn_search_dest
            // 
            this.btn_search_dest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search_dest.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search_dest.Location = new System.Drawing.Point(264, 15);
            this.btn_search_dest.Name = "btn_search_dest";
            this.btn_search_dest.Size = new System.Drawing.Size(132, 34);
            this.btn_search_dest.TabIndex = 7;
            this.btn_search_dest.Text = "Search";
            this.btn_search_dest.UseVisualStyleBackColor = true;
            this.btn_search_dest.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // txt_f_search_dest
            // 
            this.txt_f_search_dest.Location = new System.Drawing.Point(43, 25);
            this.txt_f_search_dest.Name = "txt_f_search_dest";
            this.txt_f_search_dest.Size = new System.Drawing.Size(184, 22);
            this.txt_f_search_dest.TabIndex = 6;
            // 
            // lbl_duration
            // 
            this.lbl_duration.AutoSize = true;
            this.lbl_duration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_duration.Location = new System.Drawing.Point(485, 201);
            this.lbl_duration.Name = "lbl_duration";
            this.lbl_duration.Size = new System.Drawing.Size(85, 25);
            this.lbl_duration.TabIndex = 3;
            this.lbl_duration.Text = "Duration";
            // 
            // pnl_f_data
            // 
            this.pnl_f_data.AutoScroll = true;
            this.pnl_f_data.Location = new System.Drawing.Point(7, 231);
            this.pnl_f_data.Name = "pnl_f_data";
            this.pnl_f_data.Size = new System.Drawing.Size(1110, 408);
            this.pnl_f_data.TabIndex = 4;
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.Location = new System.Drawing.Point(338, 197);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(63, 29);
            this.lbl_date.TabIndex = 2;
            this.lbl_date.Text = "Date";
            // 
            // lbl_dest
            // 
            this.lbl_dest.AutoSize = true;
            this.lbl_dest.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dest.Location = new System.Drawing.Point(141, 202);
            this.lbl_dest.Name = "lbl_dest";
            this.lbl_dest.Size = new System.Drawing.Size(109, 25);
            this.lbl_dest.TabIndex = 1;
            this.lbl_dest.Text = "Destination";
            // 
            // lbl_flight_num
            // 
            this.lbl_flight_num.AutoSize = true;
            this.lbl_flight_num.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_flight_num.Location = new System.Drawing.Point(14, 199);
            this.lbl_flight_num.Name = "lbl_flight_num";
            this.lbl_flight_num.Size = new System.Drawing.Size(89, 25);
            this.lbl_flight_num.TabIndex = 0;
            this.lbl_flight_num.Text = "Flight No";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(0, 22);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(8, 8);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(0, 22);
            this.textBox2.TabIndex = 1;
            // 
            // pnl_search_air
            // 
            this.pnl_search_air.Controls.Add(this.pnl_a_data);
            this.pnl_search_air.Controls.Add(this.label9);
            this.pnl_search_air.Controls.Add(this.label3);
            this.pnl_search_air.Controls.Add(this.label4);
            this.pnl_search_air.Controls.Add(this.label5);
            this.pnl_search_air.Controls.Add(this.label6);
            this.pnl_search_air.Controls.Add(this.label7);
            this.pnl_search_air.Controls.Add(this.label8);
            this.pnl_search_air.Controls.Add(this.btn_a_search_name);
            this.pnl_search_air.Controls.Add(this.txt_a_search);
            this.pnl_search_air.Controls.Add(this.btn_a_search);
            this.pnl_search_air.Controls.Add(this.btn_a_all_data);
            this.pnl_search_air.Controls.Add(this.textBox2);
            this.pnl_search_air.Controls.Add(this.textBox1);
            this.pnl_search_air.Location = new System.Drawing.Point(566, 57);
            this.pnl_search_air.Name = "pnl_search_air";
            this.pnl_search_air.Size = new System.Drawing.Size(1124, 651);
            this.pnl_search_air.TabIndex = 32;
            this.pnl_search_air.Visible = false;
            // 
            // pnl_a_data
            // 
            this.pnl_a_data.AutoScroll = true;
            this.pnl_a_data.Location = new System.Drawing.Point(10, 240);
            this.pnl_a_data.Name = "pnl_a_data";
            this.pnl_a_data.Size = new System.Drawing.Size(1110, 408);
            this.pnl_a_data.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(941, 180);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(180, 24);
            this.label9.TabIndex = 12;
            this.label9.Text = "No. of flights per day";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(784, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "No. of Planes";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(641, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "Rate";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(494, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Routes";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(301, 180);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 29);
            this.label6.TabIndex = 8;
            this.label6.Text = "Services";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(175, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(10, 180);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 25);
            this.label8.TabIndex = 6;
            this.label8.Text = "Airline No.";
            // 
            // btn_a_search_name
            // 
            this.btn_a_search_name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_a_search_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_a_search_name.Location = new System.Drawing.Point(920, 112);
            this.btn_a_search_name.Name = "btn_a_search_name";
            this.btn_a_search_name.Size = new System.Drawing.Size(167, 34);
            this.btn_a_search_name.TabIndex = 5;
            this.btn_a_search_name.Text = "search";
            this.btn_a_search_name.UseVisualStyleBackColor = true;
            this.btn_a_search_name.Visible = false;
            this.btn_a_search_name.Click += new System.EventHandler(this.btn_a_search_Click);
            // 
            // txt_a_search
            // 
            this.txt_a_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_a_search.Location = new System.Drawing.Point(639, 111);
            this.txt_a_search.Name = "txt_a_search";
            this.txt_a_search.Size = new System.Drawing.Size(234, 34);
            this.txt_a_search.TabIndex = 4;
            this.txt_a_search.Visible = false;
            // 
            // btn_a_search
            // 
            this.btn_a_search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.btn_a_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_a_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_a_search.Location = new System.Drawing.Point(561, 15);
            this.btn_a_search.Name = "btn_a_search";
            this.btn_a_search.Size = new System.Drawing.Size(560, 60);
            this.btn_a_search.TabIndex = 3;
            this.btn_a_search.Text = "Search Airline";
            this.btn_a_search.UseVisualStyleBackColor = false;
            this.btn_a_search.Click += new System.EventHandler(this.btn_a_search_Click_1);
            // 
            // btn_a_all_data
            // 
            this.btn_a_all_data.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_a_all_data.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_a_all_data.Location = new System.Drawing.Point(7, 15);
            this.btn_a_all_data.Name = "btn_a_all_data";
            this.btn_a_all_data.Size = new System.Drawing.Size(560, 60);
            this.btn_a_all_data.TabIndex = 2;
            this.btn_a_all_data.Text = "All Airline Data";
            this.btn_a_all_data.UseVisualStyleBackColor = true;
            this.btn_a_all_data.Click += new System.EventHandler(this.btn_a_all_data_Click);
            // 
            // pnl_resch_data
            // 
            this.pnl_resch_data.AutoScroll = true;
            this.pnl_resch_data.Location = new System.Drawing.Point(10, 79);
            this.pnl_resch_data.Name = "pnl_resch_data";
            this.pnl_resch_data.Size = new System.Drawing.Size(1104, 312);
            this.pnl_resch_data.TabIndex = 33;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(828, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 25);
            this.label10.TabIndex = 39;
            this.label10.Text = "Airline";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(607, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(201, 25);
            this.label11.TabIndex = 38;
            this.label11.Text = "Number of Passenger";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(485, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 25);
            this.label12.TabIndex = 37;
            this.label12.Text = "Duration";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(338, 18);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 29);
            this.label13.TabIndex = 36;
            this.label13.Text = "Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(141, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 25);
            this.label14.TabIndex = 35;
            this.label14.Text = "Destination";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(14, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(89, 25);
            this.label15.TabIndex = 34;
            this.label15.Text = "Flight No";
            // 
            // pnl_resch
            // 
            this.pnl_resch.Controls.Add(this.label10);
            this.pnl_resch.Controls.Add(this.label11);
            this.pnl_resch.Controls.Add(this.label12);
            this.pnl_resch.Controls.Add(this.label13);
            this.pnl_resch.Controls.Add(this.label14);
            this.pnl_resch.Controls.Add(this.label15);
            this.pnl_resch.Controls.Add(this.pnl_resch_data);
            this.pnl_resch.Location = new System.Drawing.Point(207, 330);
            this.pnl_resch.Name = "pnl_resch";
            this.pnl_resch.Size = new System.Drawing.Size(1124, 396);
            this.pnl_resch.TabIndex = 40;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(55)))));
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.White;
            this.richTextBox1.Location = new System.Drawing.Point(394, 294);
            this.richTextBox1.MaxLength = 100;
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(1081, 460);
            this.richTextBox1.TabIndex = 41;
            this.richTextBox1.Text = "";
            this.richTextBox1.Visible = false;
            // 
            // btn_exit
            // 
            this.btn_exit.BackgroundImage = global::WindowsFormsApplication2.Properties.Resources.exit1;
            this.btn_exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Location = new System.Drawing.Point(1291, 0);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(40, 40);
            this.btn_exit.TabIndex = 31;
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // Form3
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(1333, 738);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.pnl_search_f);
            this.Controls.Add(this.pnl_search_air);
            this.Controls.Add(this.pnl_resch);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.pnl_yellow);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.pnl_menu_btns.ResumeLayout(false);
            this.pnl_search_f.ResumeLayout(false);
            this.pnl_search_f.PerformLayout();
            this.pnl_search_id.ResumeLayout(false);
            this.pnl_search_id.PerformLayout();
            this.pnl_search_dest.ResumeLayout(false);
            this.pnl_search_dest.PerformLayout();
            this.pnl_search_air.ResumeLayout(false);
            this.pnl_search_air.PerformLayout();
            this.pnl_resch.ResumeLayout(false);
            this.pnl_resch.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_resch;
        private System.Windows.Forms.Button btn_search_air;
        private System.Windows.Forms.Button btn_search_f;
        private System.Windows.Forms.Panel pnl_logo;
        private System.Windows.Forms.Panel pnl_menu_btns;
        private System.Windows.Forms.Button btn_f_search_dest;
        private System.Windows.Forms.Button btn_f_search_num;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnl_yellow;
        private System.Windows.Forms.Panel pnl_search_f;
        private System.Windows.Forms.Panel pnl_f_data;
        private System.Windows.Forms.Label lbl_airline;
        private System.Windows.Forms.Label lbl_num_of_p;
        private System.Windows.Forms.Label lbl_duration;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label lbl_dest;
        private System.Windows.Forms.Label lbl_flight_num;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button btn_all_f_data;
        private System.Windows.Forms.Panel pnl_search_dest;
        private System.Windows.Forms.Button btn_search_dest;
        private System.Windows.Forms.TextBox txt_f_search_dest;
        private System.Windows.Forms.Panel pnl_search_id;
        private System.Windows.Forms.Button btn_search_id;
        private System.Windows.Forms.TextBox txt_f_search_id;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel pnl_search_air;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_a_search_name;
        private System.Windows.Forms.TextBox txt_a_search;
        private System.Windows.Forms.Button btn_a_search;
        private System.Windows.Forms.Button btn_a_all_data;
        private System.Windows.Forms.Panel pnl_a_data;
        private System.Windows.Forms.Panel pnl_resch_data;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel pnl_resch;
        private System.Windows.Forms.Button btn_alerts;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btn_logout;
    }
}

