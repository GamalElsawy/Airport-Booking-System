﻿namespace WindowsFormsApplication2
{
    partial class EditAirline
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelleft = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_logout = new System.Windows.Forms.Button();
            this.btn_send_alert = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.editflight = new System.Windows.Forms.Button();
            this.pnl_search_air = new System.Windows.Forms.Panel();
            this.pnl_a_data = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_a_search_name = new System.Windows.Forms.Button();
            this.txt_a_search = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btn_a_edit = new System.Windows.Forms.Button();
            this.btn_a_all_data = new System.Windows.Forms.Button();
            this.pnl_a_upd = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.rate = new System.Windows.Forms.ComboBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.route = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_exit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.pnl_search_air.SuspendLayout();
            this.pnl_a_upd.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelleft
            // 
            this.panelleft.BackColor = System.Drawing.Color.Yellow;
            this.panelleft.Location = new System.Drawing.Point(200, 267);
            this.panelleft.Margin = new System.Windows.Forms.Padding(4);
            this.panelleft.Name = "panelleft";
            this.panelleft.Size = new System.Drawing.Size(4, 90);
            this.panelleft.TabIndex = 40;
            this.panelleft.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_logout);
            this.panel1.Controls.Add(this.btn_send_alert);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.editflight);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 691);
            this.panel1.TabIndex = 39;
            // 
            // btn_logout
            // 
            this.btn_logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(77)))), ((int)(((byte)(77)))));
            this.btn_logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_logout.Location = new System.Drawing.Point(0, 640);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(200, 48);
            this.btn_logout.TabIndex = 7;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = false;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_send_alert
            // 
            this.btn_send_alert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.btn_send_alert.FlatAppearance.BorderSize = 0;
            this.btn_send_alert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_send_alert.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_send_alert.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_send_alert.Location = new System.Drawing.Point(0, 355);
            this.btn_send_alert.Margin = new System.Windows.Forms.Padding(4);
            this.btn_send_alert.Name = "btn_send_alert";
            this.btn_send_alert.Size = new System.Drawing.Size(198, 90);
            this.btn_send_alert.TabIndex = 6;
            this.btn_send_alert.Text = "Send Alert";
            this.btn_send_alert.UseVisualStyleBackColor = false;
            this.btn_send_alert.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.button1.Location = new System.Drawing.Point(0, 265);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(198, 90);
            this.button1.TabIndex = 5;
            this.button1.Text = "Edit Airline";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // editflight
            // 
            this.editflight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.editflight.FlatAppearance.BorderSize = 0;
            this.editflight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editflight.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editflight.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.editflight.Location = new System.Drawing.Point(0, 175);
            this.editflight.Margin = new System.Windows.Forms.Padding(4);
            this.editflight.Name = "editflight";
            this.editflight.Size = new System.Drawing.Size(198, 90);
            this.editflight.TabIndex = 4;
            this.editflight.Text = "Edit Flight";
            this.editflight.UseVisualStyleBackColor = false;
            this.editflight.Click += new System.EventHandler(this.editflight_Click);
            // 
            // pnl_search_air
            // 
            this.pnl_search_air.Controls.Add(this.pnl_a_data);
            this.pnl_search_air.Controls.Add(this.label9);
            this.pnl_search_air.Controls.Add(this.label3);
            this.pnl_search_air.Controls.Add(this.label4);
            this.pnl_search_air.Controls.Add(this.label5);
            this.pnl_search_air.Controls.Add(this.label6);
            this.pnl_search_air.Controls.Add(this.label7);
            this.pnl_search_air.Controls.Add(this.label8);
            this.pnl_search_air.Controls.Add(this.btn_a_search_name);
            this.pnl_search_air.Controls.Add(this.txt_a_search);
            this.pnl_search_air.Controls.Add(this.textBox2);
            this.pnl_search_air.Controls.Add(this.textBox1);
            this.pnl_search_air.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.pnl_search_air.Location = new System.Drawing.Point(219, 109);
            this.pnl_search_air.Name = "pnl_search_air";
            this.pnl_search_air.Size = new System.Drawing.Size(1084, 582);
            this.pnl_search_air.TabIndex = 41;
            this.pnl_search_air.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_search_air_Paint);
            // 
            // pnl_a_data
            // 
            this.pnl_a_data.AutoScroll = true;
            this.pnl_a_data.Location = new System.Drawing.Point(12, 150);
            this.pnl_a_data.Name = "pnl_a_data";
            this.pnl_a_data.Size = new System.Drawing.Size(1077, 408);
            this.pnl_a_data.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label9.Location = new System.Drawing.Point(900, 107);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(180, 24);
            this.label9.TabIndex = 12;
            this.label9.Text = "No. of flights per day";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label3.Location = new System.Drawing.Point(729, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "No. of Planes";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label4.Location = new System.Drawing.Point(624, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "Rate";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label5.Location = new System.Drawing.Point(476, 109);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Routes";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label6.Location = new System.Drawing.Point(309, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 29);
            this.label6.TabIndex = 8;
            this.label6.Text = "Services";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label7.Location = new System.Drawing.Point(174, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label8.Location = new System.Drawing.Point(16, 110);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 25);
            this.label8.TabIndex = 6;
            this.label8.Text = "Airline No.";
            // 
            // btn_a_search_name
            // 
            this.btn_a_search_name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_a_search_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_a_search_name.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_a_search_name.Location = new System.Drawing.Point(922, 22);
            this.btn_a_search_name.Name = "btn_a_search_name";
            this.btn_a_search_name.Size = new System.Drawing.Size(158, 34);
            this.btn_a_search_name.TabIndex = 5;
            this.btn_a_search_name.Text = "search";
            this.btn_a_search_name.UseVisualStyleBackColor = true;
            this.btn_a_search_name.Click += new System.EventHandler(this.btn_a_search_name_Click);
            // 
            // txt_a_search
            // 
            this.txt_a_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_a_search.Location = new System.Drawing.Point(641, 21);
            this.txt_a_search.MaxLength = 30;
            this.txt_a_search.Name = "txt_a_search";
            this.txt_a_search.Size = new System.Drawing.Size(234, 34);
            this.txt_a_search.TabIndex = 4;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(8, 8);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(0, 22);
            this.textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(0, 22);
            this.textBox1.TabIndex = 0;
            // 
            // btn_a_edit
            // 
            this.btn_a_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(72)))), ((int)(((byte)(75)))));
            this.btn_a_edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_a_edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_a_edit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_a_edit.Location = new System.Drawing.Point(775, 43);
            this.btn_a_edit.Name = "btn_a_edit";
            this.btn_a_edit.Size = new System.Drawing.Size(531, 60);
            this.btn_a_edit.TabIndex = 3;
            this.btn_a_edit.Text = "Edit Airline";
            this.btn_a_edit.UseVisualStyleBackColor = false;
            this.btn_a_edit.Click += new System.EventHandler(this.btn_a_edit_Click);
            // 
            // btn_a_all_data
            // 
            this.btn_a_all_data.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_a_all_data.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_a_all_data.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.btn_a_all_data.Location = new System.Drawing.Point(221, 43);
            this.btn_a_all_data.Name = "btn_a_all_data";
            this.btn_a_all_data.Size = new System.Drawing.Size(560, 60);
            this.btn_a_all_data.TabIndex = 2;
            this.btn_a_all_data.Text = "All Airline Data";
            this.btn_a_all_data.UseVisualStyleBackColor = true;
            this.btn_a_all_data.Click += new System.EventHandler(this.btn_a_all_data_Click);
            // 
            // pnl_a_upd
            // 
            this.pnl_a_upd.Controls.Add(this.button3);
            this.pnl_a_upd.Controls.Add(this.label1);
            this.pnl_a_upd.Controls.Add(this.label2);
            this.pnl_a_upd.Controls.Add(this.label10);
            this.pnl_a_upd.Controls.Add(this.rate);
            this.pnl_a_upd.Controls.Add(this.txt_name);
            this.pnl_a_upd.Controls.Add(this.route);
            this.pnl_a_upd.Location = new System.Drawing.Point(211, 192);
            this.pnl_a_upd.Name = "pnl_a_upd";
            this.pnl_a_upd.Size = new System.Drawing.Size(1079, 315);
            this.pnl_a_upd.TabIndex = 42;
            this.pnl_a_upd.Visible = false;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.button3.Location = new System.Drawing.Point(726, 29);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(346, 249);
            this.button3.TabIndex = 43;
            this.button3.Text = "Update Airline";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label1.Location = new System.Drawing.Point(445, 226);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 29);
            this.label1.TabIndex = 12;
            this.label1.Text = "rate";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label2.Location = new System.Drawing.Point(445, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 29);
            this.label2.TabIndex = 11;
            this.label2.Text = "route";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(128)))), ((int)(((byte)(138)))));
            this.label10.Location = new System.Drawing.Point(445, 39);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 29);
            this.label10.TabIndex = 10;
            this.label10.Text = "name";
            // 
            // rate
            // 
            this.rate.FormattingEnabled = true;
            this.rate.Location = new System.Drawing.Point(143, 219);
            this.rate.Name = "rate";
            this.rate.Size = new System.Drawing.Size(199, 24);
            this.rate.TabIndex = 9;
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(143, 39);
            this.txt_name.MaxLength = 30;
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(199, 22);
            this.txt_name.TabIndex = 8;
            // 
            // route
            // 
            this.route.Location = new System.Drawing.Point(143, 129);
            this.route.MaxLength = 30;
            this.route.Name = "route";
            this.route.Size = new System.Drawing.Size(199, 22);
            this.route.TabIndex = 7;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Yellow;
            this.panel2.BackgroundImage = global::WindowsFormsApplication2.Properties.Resources.images__1_5;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(198, 176);
            this.panel2.TabIndex = 1;
            // 
            // btn_exit
            // 
            this.btn_exit.BackgroundImage = global::WindowsFormsApplication2.Properties.Resources.exit1;
            this.btn_exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Location = new System.Drawing.Point(1276, 0);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(40, 40);
            this.btn_exit.TabIndex = 38;
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // EditAirline
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(1315, 691);
            this.Controls.Add(this.pnl_a_upd);
            this.Controls.Add(this.pnl_search_air);
            this.Controls.Add(this.panelleft);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_a_all_data);
            this.Controls.Add(this.btn_a_edit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditAirline";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditAirline";
            this.panel1.ResumeLayout(false);
            this.pnl_search_air.ResumeLayout(false);
            this.pnl_search_air.PerformLayout();
            this.pnl_a_upd.ResumeLayout(false);
            this.pnl_a_upd.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Panel panelleft;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_send_alert;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button editflight;
        private System.Windows.Forms.Panel pnl_search_air;
        private System.Windows.Forms.Panel pnl_a_data;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_a_search_name;
        private System.Windows.Forms.TextBox txt_a_search;
        private System.Windows.Forms.Button btn_a_edit;
        private System.Windows.Forms.Button btn_a_all_data;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel pnl_a_upd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox rate;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox route;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_logout;
    }
}